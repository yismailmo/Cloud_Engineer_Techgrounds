'''
The output should be:
30
'''
foo = 20
for i in range(10):
	foo -= 1

print(foo)