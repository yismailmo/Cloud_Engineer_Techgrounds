'''
The output should be:
100
'''
foo = 20
bar = '80'
print(foo + bar)