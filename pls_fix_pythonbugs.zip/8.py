'''
The output should be:
20
'''
foo = 10
bar = 2
print(foo**bar)