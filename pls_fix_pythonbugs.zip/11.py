'''
The output should be:
IT LIVES!
'''
dev monster():
	print('IT LIVES!')

monster()