'''
The output should be:
the number is 20
'''
print('the number is' + 20)