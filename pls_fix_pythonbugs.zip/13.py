'''
The output should be:
Your random number is: <insert random number here>
'''
import random

random.randint(1,100)
print("Your random number is:")